package com.upc.api_examen_parcial_202019858.repository;
import com.upc.api_examen_parcial_202019858.entities.Role;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RoleRepository extends JpaRepository<Role, Long> {
}
